# -*- coding: utf-8 -*-
"""this utf-8 doc string have some     non ASCII caracters like 'é', or '¢»ß'"""
### check also comments with some     more non ASCII caracters like 'é' or '¢»ß'

__revision__ = 1100

ASCII = "----------------------------------------------------------------------"
UTF_8 = "--------------------------------------------------------------------éé"

