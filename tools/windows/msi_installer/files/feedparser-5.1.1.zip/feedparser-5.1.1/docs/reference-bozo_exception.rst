:py:attr:`bozo_exception`
=========================

The exception raised when attempting to parse a non-well-formed feed.

See :ref:`advanced.bozo` for more details.

.. tip::

    :py:attr:`bozo_exception` will only be present if :py:attr:`bozo` is ``1``.
